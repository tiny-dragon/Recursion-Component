import React, { Component } from 'react';

class BlogItem extends Component {
    child_index = 0;

    constructor(props) {
        super(props);
        this.state = {
            index: props.index,
            subject: props.subject,
            content: props.content,
            status: props.status,
            child_blog_list: props.child_blog_list
        };
    }

    // static getDerivedStateFromProps(nextProps, prevState) {
    //     if (prevState.index === 0) {
    //         return { index: nextProps.index, subject: nextProps.subject, content: nextProps.content, status: nextProps.status, child_blog_list: nextProps.child_blog_list };
    //     } else {
    //         return { index: prevState.index, subject: prevState.subject, content: prevState.content, status: prevState.status, child_blog_list: prevState.child_blog_list };
    //     }
    // }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.index === this.state.index &&
            nextState.subject === this.state.subject &&
            nextState.content === this.state.content &&
            nextState.status === this.state.status &&
            nextState.child_blog_list === this.state.child_blog_list &&
            nextProps.index === this.props.index &&
            nextProps.subject === this.props.subject &&
            nextProps.content === this.props.content &&
            nextProps.status === this.props.status &&
            nextProps.child_blog_list === this.props.child_blog_list)
            return false
        return true
    }
    
    handleDeleteChild = (index) => {
        const child_blog_list = this.state.child_blog_list;
        this.setState({
            child_blog_list: child_blog_list.filter(info => info.index !== index)
        })
    }

    handleDelete = () => {
        this.props.onDelete(this.state.index)
    }

    handleUpdateChild = (data) => {
        const child_blog_list = this.state.child_blog_list;
        this.setState({ child_blog_list: child_blog_list.map( info => info.index === data.index ? { ...info, ...data } : info ) })
    }

    handleReply = () => {
        const child_blog_list = this.state.child_blog_list;
        this.setState({
            child_blog_list: child_blog_list.concat({index: ++this.child_index, subject:'', content:'', status:true, child_blog_list:[]})
        })
    }

    handleStatusToggle = () => {
        const status = this.state.status;
        this.setState({ status: !status });
    }

    componentDidUpdate(prevProps, prevState) {
        if(!prevState.status && this.state.status) {
            this.setState({
                index: this.props.index,
                subject: this.props.subject,
                content: this.props.content,
            })
        }
    
        if (prevState.status && !this.state.status) {
            this.props.onUpdate({index:this.state.index, subject: this.state.subject, content: this.state.content, status: this.state.status, child_blog_list: this.state.child_blog_list})
        }
    }

    handleChange = (e) => {
        this.setState({[e.target.name]: e.target.value})
    }

    render() {
        const style = {
            paddingLeft: '20px'
        }
        const child_blog_list = this.state.child_blog_list;
        const list = child_blog_list.map(
            info => (<BlogItem key={info.index} index={info.index} subject={info.subject} content={info.content} status={info.status} child_blog_list={info.child_blog_list} onUpdate={this.handleUpdateChild} onDelete={this.handleDeleteChild} />)
        );
        let blog_item = null
        if (this.state.status === true)
            blog_item = (
                <div>
                    <div className="input-panel">
                        <div><input placeholder="제목" value={this.state.subject} onChange={this.handleChange} name="subject" /></div>
                        <div><textarea placeholder="내용" value={this.state.content} onChange={this.handleChange} name="content"></textarea></div>
                        <button onClick={this.handleStatusToggle}>등록</button>
                    </div>
                    <div style={style}>
                        {list}
                    </div>
                </div>
            )
        else
            blog_item = (
                <div className="show-panel">
                    <div className="subject">
                        <b>{this.props.subject}</b>
                        <button onClick={this.handleStatusToggle}>edit</button>
                        <button onClick={this.handleDelete}>delete</button>
                        <button onClick={this.handleReply}>reply</button>
                    </div>
                    <div className="content">{this.props.content}</div>
                    <div style={style}>
                        {list}
                    </div>
                </div>
            )
        return (
            <div>
                {blog_item}
            </div>
        );
    }
}

export default BlogItem;