import { combineReducers } from 'redux';
import blog from './blog';

export default combineReducers({
  blog
});