import React, { Component } from 'react';
import BlogItem from './components/BlogItem';
import './App.css'

class App extends Component {
  blog_index = 2

  state = {
    subject: '',
    content: '',
    blog_list : [
      {index:1, subject:'subject1', content:'content1', status:false, child_blog_list:[]},
      {index:2, subject:'subject2', content:'content2', status:false, child_blog_list:[]},
    ]
  }

  handleDelete = (index) => {
    const blog_list = this.state.blog_list;
    this.setState({
      blog_list: blog_list.filter(info => info.index !== index)
    })
  }

  handleUpdate = (data) => {
    const blog_list = this.state.blog_list;
    this.setState({ blog_list: blog_list.map( info => info.index === data.index ? { ...info, ...data } : info ) })
  }

  handleChange = (e) => {
    this.setState({[e.target.name]: e.target.value})
  }

  handleCreate = () => {
    const blog_list = this.state.blog_list;
    this.setState({
      blog_list: blog_list.concat({index: ++this.blog_index, ...{subject:this.state.subject, content:this.state.content, status:false, child_blog_list:[]}}),
      subject: '',
      content: ''
    })
  }

  render() {
    const blog_list = this.state.blog_list;
    const list = blog_list.map(
      info => (<BlogItem key={info.index} index={info.index} subject={info.subject} content={info.content} status={info.status} child_blog_list={info.child_blog_list} onUpdate={this.handleUpdate} onDelete={this.handleDelete}/>)
    );

    return (
      <div>
        {list}
        <div className="input-panel">
          <div><input placeholder="제목" value={this.state.subject} onChange={this.handleChange} name="subject" /></div>
          <div><textarea placeholder="내용" value={this.state.content} onChange={this.handleChange} name="content"></textarea></div>
          <button onClick={this.handleCreate}>등록</button>
        </div>
      </div>
    );
  }
}

export default App;